#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <stdbool.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <dirent.h>

int print_prompt() {
	printf("@> ");
	return 1;
}

int get_command(char command[8192]) {	

	if(fgets(command, 8192, stdin) != NULL) {
		int len = strlen(command);
		//printf("%d\n", len);

		if(command[len-1] != '\n') {
			fprintf(stderr, "command too long\n");

		}

		command[strcspn(command, "\n")] = 0;
		return 1;
	}
	else {
		exit(0);
	}
}

int process_command(char* command) {
	char cwd[256];
	const char delim[2] = " ";
	char* token;
	char cpy[8192];

	strcpy(cpy, command);

	token = strtok(command, delim);

	if(strcmp(command, "exit") ==0) {
		exit(0);
	}

	else if(strcmp(command, "author") ==0){
		printf("Name:  Tyler LaBreck\n");
	}

	else if(strcmp(command, "cdir") == 0) {
		int count = 0;

		while(token != NULL) {
			if (strcmp(token, "cdir") != 0) {
				if(chdir(token) != 0) {
					perror("cdir");
				}
			}
			token = strtok(NULL, delim);
			count++;
		}
		if (count == 1) {
			if(getcwd(cwd, sizeof(cwd)) == NULL) {
				perror("cdir: No such file or directory");		
			}
			else {
				printf("%s\n", cwd);
			}
		}
	}

	else if(strcmp(command, "create") == 0) {
		int count = 0;

		while(token != NULL) {	
			if(strcmp(token, "-d") == 0) {
				while(token != NULL) {
					if(strcmp(token, "-d") != 0) {
						if(mkdir(token, 0777) != 0) {
							perror("create");
						}
					}
					token = strtok(NULL, delim);
					count++;
				}
				if(count == 2) {
					fprintf(stderr, "Usage: create [-d] name.\n");
				}	
			}
			token = strtok(NULL, delim);
			count++;	
		}
		if(count == 2) {
			token = strtok(cpy, delim);
			while(token != NULL) {
				if(strcmp(token, "create") != 0) {
					FILE *fp;
					fp = fopen(token, "w+");
					fclose(fp);
				}
				token = strtok(NULL, delim);
			}	
		}
		if(count == 1) {
			fprintf(stderr, "Usage: create [-d] name.\n");
		}	
	}

	else if(strcmp(command, "list") == 0) {
		struct dirent *de;
		
		DIR *dr = opendir(".");

		if(dr == NULL) {
			perror("list");
			return 0;
		}
		while((de = readdir(dr)) != NULL) {
			printf("%s\n", de->d_name);
		}
		closedir(dr);
	}
	else {
		printf("Unrecognized command:");
		while(token != NULL) {
			printf(" %s", token);

			token = strtok(NULL, delim);
		}
		printf("\n");
	}
	return 1;
}

int main(int argc, char *argv[]) {
	char command[8192];
	bool echo = false;
	int counter = 0;
	int printed = 0;

	if(argc >= 2 && strcmp(argv[1], "--echo") == 0) {
		echo = true;
	}

	if(!isatty(STDIN_FILENO)) {
		while(fgets(command, 8192, stdin) != NULL) {
			counter++;
		}
		rewind(stdin);
	}

	while(1) {
		if((!isatty(STDIN_FILENO)) && (echo == true) && (printed < counter)) {	
		print_prompt();
		printed++;
		}
		else if(isatty(0)) {
			print_prompt();
		}
		
		get_command(&command);

		if(echo == true) {
			printf("%s\n", command);
		}

		process_command(command);
	}

}


