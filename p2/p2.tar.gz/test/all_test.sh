echo "testing project 2 functionality..."
./test/all_test_p2.sh
#############################################################################
echo 
echo "testing project 1 functionality..."
#############################################################################
./test/all_test_p1.sh