#include <stdio.h>
int main(int argc, char *argv[]) {
	char *string1 = argv[1];
	char *string2 = argv[2];

	printf("%s\n", string1);
	printf("%s\n", string2);

	return 0;
}
